import { NextResponse } from "next/server";

export async function GET() {
<<<<<<< HEAD
  const headers = new Headers();
  headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');

  return NextResponse.json({ message: "Hello, world!" }, { headers });
=======
  return NextResponse.json({ message: "Hello, world!" });
>>>>>>> d13c2f0 (ed6e9115-2e51-44e6-8024-523b63f15bf6)
}